export const products = [
 {name:'Lipoless MD 15MG', category:'Tirzepatida', price:'R$ 390,00', tag:'Promoção'},
 {name:'Lipoless 15MG 4 Ampolas', category:'Tirzepatida', price:'R$ 400,00', tag:'Oferta'},
 {name:'Tirzec MD 15MG', category:'Tirzepatida', price:'R$ 440,00', tag:'Premium'},
 {name:'Tirzec 15MG 4 Ampolas', category:'Tirzepatida', price:'R$ 485,00', tag:'Lançamento'},
 {name:'Lipoland 15MG', category:'Tirzepatida', price:'R$ 485,00', tag:'Top venda'},
 {name:'Gluconex 15MG', category:'Tirzepatida', price:'R$ 485,00', tag:'Premium'},
 {name:'Creatina Monohidratada Growth', category:'Suplementos', price:'Consultar', tag:'Performance'},
 {name:'Whey Protein Premium', category:'Suplementos', price:'Consultar', tag:'Fitness'},
 {name:'GHK-CU', category:'Peptídeos', price:'Consultar', tag:'Skin care'},
 {name:'BPC-157', category:'Peptídeos', price:'Consultar', tag:'Protocolo'},
 {name:'KPV 10MG', category:'Peptídeos', price:'Consultar', tag:'Premium'},
 {name:'Vitaminas Importadas', category:'Vitaminas', price:'Consultar', tag:'Saúde'}
]
export const categories = ['Todos','Tirzepatida','Peptídeos','Suplementos','Vitaminas']
