'use client'
import { products, categories } from '@/lib/products'
import { Search, MessageCircle, ShieldCheck, Truck, Star, MapPin, Menu, X } from 'lucide-react'
import { useMemo, useState } from 'react'

const whatsapp = 'https://wa.me/5567999999999?text=Ol%C3%A1%20Suplemed%2C%20quero%20fazer%20um%20pedido'

export default function Home(){
 const [cat,setCat]=useState('Todos'); const [q,setQ]=useState(''); const [open,setOpen]=useState(false)
 const filtered=useMemo(()=>products.filter(p=>(cat==='Todos'||p.category===cat)&&p.name.toLowerCase().includes(q.toLowerCase())),[cat,q])
 return <main className="min-h-screen overflow-hidden">
  <header className="fixed top-0 z-50 w-full border-b border-white/60 bg-white/85 backdrop-blur-xl">
   <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
    <a href="#home" className="flex items-center gap-3"><div className="shine flex h-12 w-12 items-center justify-center rounded-2xl font-black text-suple-dark shadow-lg">S</div><div><p className="text-xl font-black tracking-tight text-suple-dark">SUPLEMED</p><p className="text-xs font-semibold text-suple-green">Pedro Juan Caballero - PY</p></div></a>
    <nav className="hidden items-center gap-7 font-semibold text-slate-700 md:flex"><a href="#produtos">Produtos</a><a href="#categorias">Categorias</a><a href="#sobre">Sobre</a><a href="#contato">Contato</a></nav>
    <a href={whatsapp} className="hidden rounded-full bg-suple-green px-5 py-3 font-bold text-white shadow-xl shadow-green-900/20 md:block">Comprar no WhatsApp</a>
    <button onClick={()=>setOpen(!open)} className="md:hidden">{open?<X/>:<Menu/>}</button>
   </div>
   {open&&<div className="grid gap-3 border-t bg-white p-5 font-semibold md:hidden"><a href="#produtos">Produtos</a><a href="#categorias">Categorias</a><a href="#sobre">Sobre</a><a href={whatsapp}>WhatsApp</a></div>}
  </header>

  <section id="home" className="relative pt-28">
   <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,#b7ff4a55,transparent_35%),radial-gradient(circle_at_top_right,#0b7f5540,transparent_35%)]" />
   <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 py-16 lg:grid-cols-2 lg:py-24">
    <div><span className="rounded-full bg-white px-4 py-2 text-sm font-bold text-suple-green shadow">Farmácia premium • Suplementos • Vitaminas</span><h1 className="mt-6 text-5xl font-black leading-tight text-suple-dark md:text-7xl">Sua loja premium de saúde, performance e bem-estar.</h1><p className="mt-6 max-w-xl text-lg leading-8 text-slate-600">Produtos selecionados, atendimento rápido e pedidos exclusivamente pelo WhatsApp oficial da loja.</p><div className="mt-8 flex flex-wrap gap-4"><a href={whatsapp} className="rounded-full bg-suple-green px-7 py-4 font-black text-white shadow-2xl shadow-green-900/25">Fazer pedido agora</a><a href="#produtos" className="rounded-full border border-suple-green bg-white px-7 py-4 font-black text-suple-green">Ver produtos</a></div></div>
    <div className="glass relative rounded-[2rem] p-6 shadow-2xl"><div className="rounded-[1.5rem] bg-gradient-to-br from-suple-dark via-suple-green to-lime-300 p-8 text-white"><p className="text-sm font-bold uppercase tracking-[.3em] text-lime-200">Suplemed PJC</p><h2 className="mt-4 text-4xl font-black">Ofertas e lançamentos todos os dias</h2><p className="mt-4 text-white/85">Tirzepatida, peptídeos, vitaminas importadas, suplementos e performance.</p><div className="mt-8 grid grid-cols-2 gap-4"><Info icon={<ShieldCheck/>} title="Procedência"/><Info icon={<Truck/>} title="Envios"/><Info icon={<Star/>} title="Premium"/><Info icon={<MessageCircle/>} title="WhatsApp"/></div></div></div>
   </div>
  </section>

  <section id="categorias" className="mx-auto max-w-7xl px-5 py-10"><div className="grid gap-4 md:grid-cols-4">{['Tirzepatida','Peptídeos','Suplementos','Vitaminas'].map(c=><button key={c} onClick={()=>setCat(c)} className="rounded-3xl bg-white p-6 text-left shadow-lg ring-1 ring-black/5 transition hover:-translate-y-1"><p className="text-sm font-bold text-suple-green">Categoria</p><h3 className="mt-2 text-2xl font-black text-suple-dark">{c}</h3></button>)}</div></section>

  <section id="produtos" className="mx-auto max-w-7xl px-5 py-16"><div className="flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="font-bold text-suple-green">Catálogo Suplemed</p><h2 className="text-4xl font-black text-suple-dark">Produtos em destaque</h2></div><div className="glass flex items-center gap-3 rounded-full px-5 py-3"><Search size={20}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar produto..." className="bg-transparent outline-none"/></div></div><div className="mt-7 flex flex-wrap gap-3">{categories.map(c=><button onClick={()=>setCat(c)} className={`rounded-full px-5 py-2 font-bold ${cat===c?'bg-suple-green text-white':'bg-white text-suple-green'}`} key={c}>{c}</button>)}</div><div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{filtered.map(p=><article key={p.name} className="group rounded-[1.8rem] bg-white p-5 shadow-xl ring-1 ring-black/5 transition hover:-translate-y-2"><div className="flex h-44 items-center justify-center rounded-[1.4rem] bg-gradient-to-br from-green-50 to-lime-100"><div className="shine flex h-24 w-24 items-center justify-center rounded-3xl text-3xl font-black text-suple-dark">S</div></div><div className="mt-5"><span className="rounded-full bg-lime-100 px-3 py-1 text-xs font-black text-suple-green">{p.tag}</span><h3 className="mt-3 min-h-14 text-xl font-black text-suple-dark">{p.name}</h3><p className="text-sm font-bold text-slate-500">{p.category}</p><p className="mt-3 text-2xl font-black text-suple-green">{p.price}</p><a href={whatsapp} className="mt-5 block rounded-full bg-suple-dark px-4 py-3 text-center font-black text-white">Pedir no WhatsApp</a></div></article>)}</div></section>

  <section id="sobre" className="bg-suple-dark px-5 py-20 text-white"><div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-3"><div className="md:col-span-2"><p className="font-bold text-lime-300">Atendimento profissional</p><h2 className="mt-3 text-4xl font-black">Suplemed: confiança, agilidade e padrão premium.</h2><p className="mt-5 max-w-3xl text-lg leading-8 text-white/75">Trabalhamos com atendimento direto, catálogo organizado e suporte para pedidos. Todos os pedidos são feitos apenas pelo WhatsApp oficial da loja.</p></div><div className="rounded-3xl bg-white/10 p-7"><MapPin className="text-lime-300"/><h3 className="mt-4 text-2xl font-black">Localização</h3><p className="mt-2 text-white/75">Pedro Juan Caballero - PY</p></div></div></section>

  <footer id="contato" className="bg-white px-5 py-10"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-5 md:flex-row md:items-center"><div><p className="text-2xl font-black text-suple-dark">SUPLEMED</p><p className="font-semibold text-slate-600">PEDIDOS APENAS NO WHATSAPP OFICIAL DA LOJA</p></div><a href={whatsapp} className="rounded-full bg-suple-green px-7 py-4 text-center font-black text-white">Chamar no WhatsApp</a></div></footer>
 </main>
}
function Info({icon,title}:{icon:React.ReactNode,title:string}){return <div className="rounded-2xl bg-white/15 p-4"><div className="text-lime-200">{icon}</div><p className="mt-2 font-black">{title}</p></div>}
