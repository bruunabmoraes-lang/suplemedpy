import './globals.css'
export const metadata = { title: 'Suplemed PJC | Farmácia Premium', description: 'Suplementos, vitaminas e produtos premium em Pedro Juan Caballero - PY' }
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="pt-BR"><body>{children}</body></html> }
